async function translateText() {

    const text = document.getElementById("inputText").value;
    const targetLang = document.getElementById("language").value;
    const output = document.getElementById("output");

    // Check empty input
    if (text.trim() === "") {
        output.innerText = "Please enter some text!";
        return;
    }

    output.innerText = "Translating...";

    // Google Translate API URL
    const url =
    `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=${targetLang}&dt=t&q=${encodeURIComponent(text)}`;

    try {

        const response = await fetch(url);
        const data = await response.json();

        output.innerText = data[0][0][0];

    } catch (error) {

        output.innerText = "Translation failed!";

        console.error(error);
    }
}
